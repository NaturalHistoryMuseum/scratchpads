<div class="my_field">
  <?php foreach ($items as $item) {
    print $item['view'] ?><br/>
  <?php } ?>
</div>
